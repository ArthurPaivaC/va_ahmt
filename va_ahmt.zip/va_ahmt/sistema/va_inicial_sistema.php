<?php
  if(isset($_GET['msg'])){
    echo $_GET['msg'];
  }else{
      echo "<h1>Bem vindo!</h1>";
  }
?>
