<?php
  $servidor = 'localhost';
  $usuario = 'root';
  $senha = 'root';
  $database = 'va_bd';

  $dificultar = 'd908hhd89ushd0y9ju'; //Código para auxiliar a criptografar a senha.

?>
